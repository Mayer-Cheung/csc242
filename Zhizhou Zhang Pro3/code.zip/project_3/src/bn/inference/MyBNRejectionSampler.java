package bn.inference;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import bn.core.Assignment;
import bn.core.BayesianNetwork;
import bn.core.Distribution;
import bn.core.RandomVariable;
import bn.parser.BIFParser;
import bn.parser.XMLBIFParser;

//  method of Reject sampling
public class MyBNRejectionSampler {

	//  private variables
	
	//  network get from parser
	protected static BayesianNetwork nw;
	
	//  store all the variable
	protected static List<RandomVariable> allRV;
	
	//  auxiliary numbers
	protected static int sampleTimes = 0;
	
	//  answer of the distribution
	protected static Distribution ans = new Distribution();
	
	//  record the variable is used or not
	protected static LinkedHashMap<RandomVariable,Integer> flag = new LinkedHashMap();
	
	//  store evidence variable and value
	protected static LinkedHashMap<RandomVariable,Object> preset = new LinkedHashMap();

	//  check an assignment is consistent with evidence variable
	private static Boolean consistent(Assignment ass)
	{
		//  one variable is not consistent, return false
		for (RandomVariable rv : preset.keySet())
		{
			if (!ass.get(rv).equals(preset.get(rv)) )
			{
				return false;
			}
		}
		//  after check all, return true
		return true;
	}
	
	//  trial with query variable
	private static void trail(RandomVariable quest) {
		for (int i = 0; i < sampleTimes; i++)
		{
			Assignment ass = new Assignment();
			
			//  generate one sequence
			ass = prior_sample();
			
			//  if it's consistent, add corresponding entry by one
			if (consistent(ass))
			{
				Object obj = ass.get(quest);
				double x = ans.get(obj) + 1;
				ans.put(obj, x);
			}
		}
	}
	
	//  generate an assignment by random sampling
	private static Assignment prior_sample() {
		Assignment a = new Assignment();
		
		//  generate random value for all variable
		for (RandomVariable rv : allRV)
		{
			double rd = Math.random();
			double temp = 0.0;
			//  get the value of the current variable, explained in detail in write-up
			for (Object obj : rv.getDomain())
			{
				a.put(rv, obj);
				temp += nw.getProb(rv, a);
				if (temp >= rd)
					break;
			}
		}
		return a;
	}

	//  main function
	public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {
		//  get trial times
		sampleTimes = Integer.parseInt(args[0]);
		
		//  parse xml file
		if (args[1].indexOf(".xml") != -1)
		{
			XMLBIFParser parser = new XMLBIFParser();
			nw = parser.readNetworkFromFile(args[1]);
		}
		//  parse bif file
		else
		{
			BIFParser parser = new BIFParser(new FileInputStream(args[1]));
			nw = parser.parseNetwork();
		}
		
		//  get all variable from network in topological value
		allRV = nw.getVariableListTopologicallySorted();
		
		//  initialize all variable unused
		for (RandomVariable rv : allRV)
			flag.put(rv, 0);
		
		//  get query variable, set it used, increase preset number
		RandomVariable quest = nw.getVariableByName(args[2]);
		flag.put(quest, 1);
		
		//  set evidence variable with value, increase preset number correspondingly
		for (int i = 3; i < args.length; i += 2)
		{
			RandomVariable rv = nw.getVariableByName(args[i]);
			Object b = args[i + 1];
			flag.put(rv, 1);
			preset.put(rv, b);
		}
		
		//  initialize distribution
		for (Object obj : quest.getDomain())
		{
			ans.put(obj, 0.0);
		}
		//long st = System.currentTimeMillis();
		
		
		trail(quest);
		
		//long ed = System.currentTimeMillis();
		
		//  normalize distribution
		ans.normalize();
		
		//  print answer
		for (Object obj : ans.keySet())
			System.out.println(obj + " " + ans.get(obj));
		
		//System.out.println(ed - st);
	}
}
