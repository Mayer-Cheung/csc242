package bn.inference;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import bn.core.Assignment;
import bn.core.BayesianNetwork;
import bn.core.Distribution;
import bn.core.RandomVariable;
import bn.parser.BIFParser;
import bn.parser.XMLBIFParser;

//  method of approximate inference by Likelihood Weighting
public class MyBNLikelihoodWeighting {

	//  private variables
	
	//  network get from parser
	protected static BayesianNetwork nw;
	
	//  store all the variable
	protected static List<RandomVariable> allRV;
	
	//  auxiliary numbers
	protected static int sampleTimes = 0;
	
	//  answer of the distribution
	protected static Distribution ans = new Distribution();
	
	//  record the variable is used or not
	protected static LinkedHashMap<RandomVariable,Integer> flag = new LinkedHashMap();
	
	//  store evidence variable and value
	protected static LinkedHashMap<RandomVariable,Object> preset = new LinkedHashMap();
	
	//  try with query variable
	private static void trail(RandomVariable quest) {
		for (int i = 0; i < sampleTimes; i++)
			WS(quest);
	}
	
	//  directly follow from the book
	private static void WS(RandomVariable quest) {
		Assignment ass = new Assignment();
		double w = 1.0;
		for (RandomVariable rv : allRV)
		{
			//  if the variable is evidence variable, get the value and change the weight
			if (preset.containsKey(rv))
			{
				ass.put(rv, preset.get(rv));
				w *= nw.getProb(rv, ass);
			}
			//  else go with simple random
			else
			{
				double rd = Math.random();
				double temp = 0.0;
				for (Object obj : rv.getDomain())
				{
					ass.put(rv, obj);
					temp += nw.getProb(rv, ass);
					if (temp >= rd)
						break;
				}
			}
		}
		
		//  add up with weight
		double tmp = ans.get(ass.get(quest)) + w;
		ans.put(ass.get(quest), tmp);
	}

	//  main function
	public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {
		//  get trial times
		sampleTimes = Integer.parseInt(args[0]);
		
		//  parse xml files
		if (args[1].indexOf(".xml") != -1)
		{
			XMLBIFParser parser = new XMLBIFParser();
			nw = parser.readNetworkFromFile(args[1]);
		}
		//  parse bif files
		else
		{
			BIFParser parser = new BIFParser(new FileInputStream(args[1]));
			nw = parser.parseNetwork();
		}
		
		//  store all variable in topological order
		allRV = nw.getVariableListTopologicallySorted();
		
		
		//  initialize all variable unused
		for (RandomVariable rv : allRV)
			flag.put(rv, 0);
		
		//  get query variable, set used
		RandomVariable quest = nw.getVariableByName(args[2]);
		flag.put(quest, 1);
		
		//  set evidence variable and values
		for (int i = 3; i < args.length; i += 2)
		{
			RandomVariable rv = nw.getVariableByName(args[i]);
			Object b = args[i + 1];
			flag.put(rv, 1);
			preset.put(rv, b);
		}
		
		//  initialize distribution
		for (Object obj : quest.getDomain())
		{
			ans.put(obj, 0.0);
		}
		
		//  long st = System.currentTimeMillis();
		
		trail(quest);
		
		//  long ed = System.currentTimeMillis();
		
		//  normalize distribution
		ans.normalize();
		
		//  print distribution
		for (Object obj : ans.keySet())
			System.out.println(obj + " " + ans.get(obj));
		
		//  System.out.println(ed - st);

	}



}
