package bn.inference;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import bn.core.*;
import bn.core.BayesianNetwork.Node;
import bn.parser.*;

//  method of exact inference
public class MyBNInferencer {

	//  private variable of the class
	
	//  record the variable is used or not
	protected static LinkedHashMap<RandomVariable,Integer> flag = new LinkedHashMap();
	
	//  store the evidence variables
	protected static LinkedHashMap<RandomVariable,Object> preset = new LinkedHashMap();
	
	//  store the network parsed from parser
	protected static BayesianNetwork nw;
	
	//  store all the variables from the network
	protected static List<RandomVariable> allRV;
	
	//  distribution of the query variable
	protected static Distribution ans = new Distribution();
	
	//  auxiliary number
	protected static int totalNumber = 0, presetNumber = 0;

	//  depth first search to enumerate
	protected static double dfs(int depth, Assignment ass)
	{
		double pro;
		
		//  reach the maximum depth, return the result
		if (depth == totalNumber)
		{
			pro = 1.0;
			for (RandomVariable rv : allRV)
			{
				pro *= nw.getProb(rv, ass);
			}
			return pro;
		}
		else
		{
			//  else assign next unassigned variable, try every possible value and go further
			pro = 0.0;
			for (RandomVariable rv : allRV)
			{
				if (flag.get(rv) == 0)
				{
					flag.put(rv, 1);
					for (Object obj : rv.getDomain())
					{
						ass.put(rv, obj);
						pro += dfs(depth + 1, ass);
						ass.remove(rv);
					}
					flag.put(rv, 0);
				}
			}
		}
		return pro;
	}
	
	//  query the variable with preset value obj
	protected static double query(RandomVariable q, Object obj)
	{
		double res = 0.0;
		Assignment ass = new Assignment();
		ass.put(q, obj);
		for (RandomVariable rv : preset.keySet())
			ass.put(rv, preset.get(rv));
		
		res += dfs(presetNumber, ass);
		return res;
	}
	
	//  main function
	public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {
		//  parse if it's .xml
		if (args[0].indexOf(".xml") != -1)
		{
			XMLBIFParser parser = new XMLBIFParser();
			nw = parser.readNetworkFromFile(args[0]);
		}
		else
		{
			//  parse bif
			BIFParser parser = new BIFParser(new FileInputStream(args[0]));
			nw = parser.parseNetwork();
		}
		
		//  store all variable in topological order
		allRV = nw.getVariableListTopologicallySorted();
		
		//  store total number of variable
		totalNumber = allRV.size();

		//  initialize the book
		for (RandomVariable rv : allRV)
			flag.put(rv, 0);
		
		//  get query variable
		RandomVariable quest = nw.getVariableByName(args[1]);
		
		//  set it used
		flag.put(quest, 1);
		
		//  increase preset number
		presetNumber++;
		
		//  get the evidence variables and their values, store them and increase preset number correspondingly
		for (int i = 2; i < args.length; i += 2)
		{
			RandomVariable rv = nw.getVariableByName(args[i]);
			Object b = args[i + 1];
			flag.put(rv, 1);
			preset.put(rv, b);
			presetNumber++;
		}
		
		//  query every entry in distribution
		for (Object obj : quest.getDomain())
		{
			ans.put(obj, query(quest, obj));
		}
		
		//  normalize the distribution
		ans.normalize();
		
		//  print the distribution
		for (Object obj : ans.keySet())
			System.out.println(obj + " " + ans.get(obj));
			
	}

}
